


export const addPaymentGateWay = (req, res) => {

}